import { NextResponse } from 'next/server';
import { requireOwnerOrAdmin } from '@/lib/admin-auth';
import { getAdmin } from '@/lib/firebase-admin';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

const DEFAULTS = {
  pricingEnabled: true,
  showForProviders: false,
  showForSeekers: false,
  enforceAfterMonths: 3,
  lockAllToPricing: false,
  lockProvidersToPricing: false,
  lockSeekersToPricing: false,
};

export async function GET(req: Request) {
  const authz = await requireOwnerOrAdmin(req);
  if (!authz.ok) return NextResponse.json({ error: authz.error }, { status: authz.code });

  const { db } = await getAdmin();
  const snap = await db.collection('settings').doc('features').get();
  const data = snap.exists ? snap.data() || {} : {};
  const out = {
    pricingEnabled: typeof data.pricingEnabled === 'boolean' ? data.pricingEnabled : DEFAULTS.pricingEnabled,
    showForProviders: typeof data.showForProviders === 'boolean' ? data.showForProviders : DEFAULTS.showForProviders,
    showForSeekers: typeof data.showForSeekers === 'boolean' ? data.showForSeekers : DEFAULTS.showForSeekers,
    enforceAfterMonths: Number.isFinite(data.enforceAfterMonths) ? Number(data.enforceAfterMonths) : DEFAULTS.enforceAfterMonths,
    lockAllToPricing: !!data.lockAllToPricing,
    lockProvidersToPricing: !!data.lockProvidersToPricing,
    lockSeekersToPricing: !!data.lockSeekersToPricing,
  };
  return NextResponse.json({ features: out });
}

export async function POST(req: Request) {
  const authz = await requireOwnerOrAdmin(req);
  if (!authz.ok) return NextResponse.json({ error: authz.error }, { status: authz.code });

  const body = await req.json().catch(() => ({}));
  const { db } = await getAdmin();
  const settingsRef = db.collection('settings').doc('features');
  const prevSnap = await settingsRef.get();
  const prev = prevSnap.exists ? prevSnap.data() || {} : {};
  const next = {
    pricingEnabled: !!body.pricingEnabled,
    showForProviders: !!body.showForProviders,
    showForSeekers: !!body.showForSeekers,
    enforceAfterMonths: Math.max(0, Math.floor(Number(body.enforceAfterMonths ?? DEFAULTS.enforceAfterMonths))),
    lockAllToPricing: !!body.lockAllToPricing,
    lockProvidersToPricing: !!body.lockProvidersToPricing,
    lockSeekersToPricing: !!body.lockSeekersToPricing,
  };

  await settingsRef.set(next, { merge: true });

  // Determine provider lock state transitions
  const prevProvidersLocked = !!(prev.lockAllToPricing || prev.lockProvidersToPricing);
  const nextProvidersLocked = !!(next.lockAllToPricing || next.lockProvidersToPricing);
  let updatedDemoted = 0;
  let updatedReapproved = 0;

  if (!prevProvidersLocked && nextProvidersLocked) {
    // Providers just became locked: demote all approved services
    const svcSnap = await db.collection('services').where('status', '==', 'approved').limit(5000).get();
    let batch = db.batch();
    let ops = 0;
    for (const d of svcSnap.docs) {
      batch.update(d.ref, { status: 'pending', approvedAt: null, approvedBy: null, demotedForLock: true });
      ops++;
      updatedDemoted++;
      if (ops >= 400) { await batch.commit(); batch = db.batch(); ops = 0; }
    }
    if (ops > 0) { await batch.commit(); }
  } else if (prevProvidersLocked && !nextProvidersLocked) {
    // Providers just became unlocked: reapprove any services we demoted for lock
    const svcSnap = await db.collection('services').where('status', '==', 'pending').limit(5000).get();
    let batch = db.batch();
    let ops = 0;
    for (const d of svcSnap.docs) {
      const s = d.data() || {};
      if (s.demotedForLock === true) {
        batch.update(d.ref, { status: 'approved', demotedForLock: null, approvedAt: new Date(), approvedBy: authz.uid });
        ops++;
        updatedReapproved++;
        if (ops >= 400) { await batch.commit(); batch = db.batch(); ops = 0; }
      }
    }
    if (ops > 0) { await batch.commit(); }
  }

  return NextResponse.json({ ok: true, features: next, updatedDemoted, updatedReapproved });
}
