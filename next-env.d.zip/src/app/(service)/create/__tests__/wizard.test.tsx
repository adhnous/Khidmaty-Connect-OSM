import { describe, it, expect, vi, beforeEach } from "vitest";
import React from "react";
import { render, screen, fireEvent } from "@testing-library/react";
let Page: any;

// Mocks
vi.mock("@/hooks/use-auth", () => ({
  useAuth: () => ({ user: { uid: "test-uid", email: "a@b.c" }, userProfile: { role: 'provider' }, loading: false }),
}));

vi.mock("@/lib/service-drafts", () => ({
  getServiceDraft: vi.fn(async () => null),
  saveServiceDraft: vi.fn(async () => {}),
  deleteServiceDraft: vi.fn(async () => {}),
}));

vi.mock("@/lib/i18n", async (orig) => {
  const mod: any = await orig();
  return { ...mod, getClientLocale: () => "en", tr: mod.tr };
});

describe("Create Service Wizard", () => {
  let Page: any;
  beforeEach(async () => {
    vi.resetModules();
    Page = (await import("../../create/page")).default;
  });

  it("renders the create wizard header and initial step", async () => {
    render(React.createElement(Page));
    // Title appears (English or Arabic)
    const heading = await screen.findByText(/Create Service|إنشاء خدمة/i);
    expect(heading).toBeTruthy();
  });
});

