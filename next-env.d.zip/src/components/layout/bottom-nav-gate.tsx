"use client";
import BottomNav from "./bottom-nav";

export default function BottomNavGate() {
  return <BottomNav />;
}
